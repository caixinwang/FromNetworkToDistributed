package com.msb.zookeeper.configurationcenter;

/**
 * @author: 马士兵教育
 * @create: 2019-09-20 15:08
 */
public class MyConf {

    String conf;

    public String getConf() {
        return conf;
    }

    public void setConf(String conf) {
        this.conf = conf;
    }
}
