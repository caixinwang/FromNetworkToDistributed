##  ZOOKEEPER

### IMAGE目录
```
1.  IMAGE/ZOOKEEPER理论.jpg
2.  IMAGE/ZOOKEEPER理论.pos
3.  主要是跟着视频推理分布式中的难点概念
```
### 周边知识点
```
1.  CAP定理
2.  BASE定理
3.  PAXOS论文
4.  分布式锁
```








